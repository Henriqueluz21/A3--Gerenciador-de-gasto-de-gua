/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simuladoragua;

public class Simuladoragua {
    public static void main(String[] args) {
        new logintela().setVisible(true);
    }
}


